package co.edu.unicesar.demo;

/** Clase de ejemplo de la entrega de demostracion. */
public class Main {
    public static void main(String[] args) {
        System.out.println("Control de asistencia con codigo QR");
    }
}
