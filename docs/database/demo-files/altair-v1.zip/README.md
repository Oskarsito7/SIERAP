# Control de asistencia con codigo QR

Equipo Altair - entrega v1 (archivo de demostracion de SIERAP).
