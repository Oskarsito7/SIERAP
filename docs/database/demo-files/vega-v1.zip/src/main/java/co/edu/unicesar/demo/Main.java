package co.edu.unicesar.demo;

/** Clase de ejemplo de la entrega de demostracion. */
public class Main {
    public static void main(String[] args) {
        System.out.println("Sistema de citas para el consultorio juridico");
    }
}
