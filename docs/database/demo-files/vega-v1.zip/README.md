# Sistema de citas para el consultorio juridico

Equipo Vega - entrega v1 (archivo de demostracion de SIERAP).
