package co.edu.unicesar.demo;

/** Clase de ejemplo de la entrega de demostracion. */
public class Main {
    public static void main(String[] args) {
        System.out.println("App de turnos para el comedor universitario");
    }
}
