# App de turnos para el comedor universitario

Equipo Sirius - entrega v2 (archivo de demostracion de SIERAP).
