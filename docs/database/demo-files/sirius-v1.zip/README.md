# App de turnos para el comedor universitario

Equipo Sirius - entrega v1 (archivo de demostracion de SIERAP).
